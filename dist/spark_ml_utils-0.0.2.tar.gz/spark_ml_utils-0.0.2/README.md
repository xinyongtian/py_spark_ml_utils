# spark_ml_utils

Some spark ml utilities, for easy checking/modifying spark pipeline, extracting feature importance for spark logistic regression model.



## Installation


```bash
  pip install spark_ml_utils
```


    
## How to use

[see demo here](https://github.com/xinyongtian/py_spark_ml_utils/blob/main/demo.ipynb)
